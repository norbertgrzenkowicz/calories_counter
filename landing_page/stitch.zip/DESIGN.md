```markdown
# Design System Strategy: The Kinetic Monolith

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"The Kinetic Monolith."** 

In the saturated world of wellness apps, we avoid the "soft and friendly" cliché. Instead, we embrace a high-precision, engineering-grade aesthetic inspired by the performance of Linear and the architectural clarity of Vercel. This system treats food tracking not as a chore, but as a high-fidelity data operation. 

We break the "template" look through **intentional asymmetry**—using massive display type contrasted against tiny, precise mono-spaced labels—and **tonal depth**. By stripping away traditional borders and dividers, we create an interface that feels like a single, seamless piece of dark glass, punctuated only by the electric energy of the primary neon accent.

---

## 2. Colors & Surface Logic
The palette is rooted in deep obsidian tones to minimize eye strain and maximize the "pop" of the primary accent.

### Surface Hierarchy & Nesting
To achieve a premium feel, we strictly follow the **"No-Line" Rule**: Prohibit 1px solid borders for sectioning. Use background shifts to define boundaries.

*   **Background (`#0A0A0A`):** The void. Used for the lowest level of the application.
*   **Surface (`#131313` / `surface`):** The primary canvas for content.
*   **Surface Container Low (`#1C1B1B`):** Used for subtle sectioning within a page.
*   **Surface Container High (`#2A2A2A`):** The "Elevated" state. Used for cards that sit atop the main surface.
*   **Primary Accent (`#00FF88`):** Use sparingly. This is your "Action" color. It should feel like a laser cutting through the dark.

### The Glass & Gradient Rule
Floating elements (modals, dropdowns, floating action buttons) must use **Glassmorphism**. Use a semi-transparent `surface_container_highest` with a `backdrop-blur` of 20px. This allows the neon accents of the underlying content to bleed through, creating a sense of physical space and atmospheric depth.

---

## 3. Typography
We utilize a sophisticated pairing of **Inter** for high-performance readability and **Berkeley Mono** (represented here by high-utility labels) for data points.

*   **Display & Headlines:** Use `display-lg` (3.5rem) and `headline-lg` (2rem) with a tight letter-spacing (-0.02em). These should feel "heavy" and authoritative.
*   **The Data Layer:** All numerical data (calories, macros, timestamps) should feel like a terminal readout. Use `label-md` for these technical snippets to create an "Instrument Cluster" feel.
*   **Body:** `body-md` (0.875rem) in `on_surface_variant` (#B0B0B0) provides the necessary breathing room between the aggressive headlines.

---

## 4. Elevation & Depth
Depth in this system is a product of light and layering, not structural lines.

*   **Tonal Layering:** To create a "lifted" card, place a `surface_container_high` (#2A2A2A) element on a `surface` (#131313) background. The delta in luminance provides all the separation needed.
*   **Ambient Shadows:** For floating elements, use a shadow with a 32px-64px blur at 8% opacity, tinted with `primary_container` (#00FF88). This creates a "glow" rather than a shadow, suggesting the element is emitting light.
*   **The Ghost Border:** If accessibility requires a container edge, use `outline_variant` at 15% opacity. It should be barely perceptible—a "whisper" of an edge.

---

## 5. Components

### Buttons
*   **Primary:** Solid `primary_container` (#00FF88) with `on_primary` (#003919) text. Add a 12px blur shadow of the same color at 30% opacity to create a "Neon Glow" effect.
*   **Secondary:** Ghost style. Transparent background with a `Ghost Border`. Text in `primary`.
*   **Tertiary:** Plain text in `primary` with an underline that only appears on hover.

### Input Fields
*   **The "Silent" Input:** No background color. Only a bottom border (Ghost Border) that transitions to a `primary` 1px solid line on focus. Labels sit in `label-sm` above the input in a secondary color.

### Cards & Lists
*   **No Dividers:** Forbid the use of line dividers. Separate list items using `spacing-4` (1.4rem) or by alternating subtle background shifts (`surface_container_low` vs `surface_container_lowest`).
*   **The Macro-Card:** Use `xl` (1.5rem) border-radius. Content should be padded with `spacing-6` (2rem) to ensure the "Premium Minimalist" look.

### Technical Chips
*   Used for food categories (e.g., "High Protein," "Vegan"). These are small, `sm` (0.25rem) rounded boxes with `surface_container_highest` backgrounds and `mono` type.

---

## 6. Do’s and Don’ts

### Do:
*   **Embrace the Void:** Use `spacing-16` and `spacing-20` for top-level margins. Generous whitespace is the difference between a "utility app" and a "premium experience."
*   **Micro-Interactions:** Buttons should subtly scale down (98%) on press to feel tactile.
*   **Abstract Geometry:** Use cropped, ultra-thin circles or angled lines in `primary` at 5% opacity in the background to break up large empty areas.

### Don't:
*   **No 100% White:** Avoid using `#FFFFFF` for large blocks of text. Use `on_surface` (#E5E2E1) to keep the dark-mode harmony.
*   **No Stock Imagery:** If a food photo is missing, use an abstract geometric representation of its macro-nutrients.
*   **No Standard Grids:** Experiment with offsetting your headlines. Let a headline start on column 1, while the body text starts on column 3. This "Editorial Offset" creates a high-end magazine feel.